package com.gamecodeschool.gatelogic;

class Out {
}
