package com.gamecodeschool.gatelogic;

import android.util.Log;
import android.view.MotionEvent;

class Not {
    int horizontalPosition;
    int verticalPosition;
    int blockSize;


   Not(){

    }

    //design on to the

    //public boolean
        // Has the player removed their finger from the screen?
            // Process the player's shot by passing the
            // coordinates of the player's finger to takeShot
           // makeNot(motionEvent.getX(), motionEvent.getY());

       // return true;
    //}

   // private void Not(float x, float y){
        //onTouchEvent(MotionEvent motionEvent) {
            //horizontalPosition = motionEvent.getX();
            //horizontalPosition = (int)x/ blockSize;
            //verticalPosition = (int) y / blockSize;
        //}


    }

//}
