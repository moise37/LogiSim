package com.gamecodeschool.gatelogic;

class And {
    public And(){

    }

    //canvas.drawText("BOOM!", blockSize * 4,
    //blockSize * 14, paint);
}
