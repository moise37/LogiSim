package com.gamecodeschool.gatelogic;

class Tog {
}
