package com.gamecodeschool.gatelogic;

class Or {

    public Or() {
    }
}
