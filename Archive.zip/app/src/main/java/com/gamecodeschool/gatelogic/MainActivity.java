package com.gamecodeschool.gatelogic;
import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.util.Log;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.Display;
import android.widget.ImageView;


public class MainActivity extends Activity {

    int numberHorizontalPixels;
    int numberVerticalPixels;
    int blockSize;
    int gridWidth = 40;
    int gridHeight;
    float horizontalTouched = -100;
    float verticalTouched = -100;
    // Here are all the objects(instances)
    // of classes that we need to do some drawing
    ImageView gameView;
    Bitmap blankBitmap;
    Canvas canvas;
    Paint paint;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get the current device's screen resolution
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);

        // Initialize our size based variables based on the screen resolution
        numberHorizontalPixels = size.x;
        numberVerticalPixels = size.y;
        blockSize = numberHorizontalPixels / gridWidth;
        gridHeight = numberVerticalPixels / blockSize;

        // Initialize all the objects ready for drawing
        blankBitmap = Bitmap.createBitmap(numberHorizontalPixels,
                numberVerticalPixels,
                Bitmap.Config.ARGB_8888);

        canvas = new Canvas(blankBitmap);
        gameView = new ImageView(this);
        paint = new Paint();

        setContentView(gameView);
        draw();
    }
    //Button logic
    // where the the upper portion of the grid is buttons
    void touch(float touchX, float touchY) {


        //edit determines if the button has been pressed the function should look for the next.
        // under development
        boolean edit;

        // Convert the float screen coordinates
        // into int grid coordinates
        horizontalTouched = (int) touchX / blockSize;
        verticalTouched = (int) touchY / blockSize;

        //buttons placed on the top two rows of the grid
        //when the button is triggered, the respected class is
        if (verticalTouched < 2.0 && horizontalTouched < 6.0) {
            And and = new And();
            edit = true;

            canvas.drawText("AND", blockSize * 2, blockSize * 2f, paint);
            draw();

            if (verticalTouched < 2 && horizontalTouched > 6.0 && horizontalTouched < 10.0) {
                Or or = new Or();
                edit = true;
            }
            if (verticalTouched < 2 && horizontalTouched > 10.0 && horizontalTouched < 15.0) {
                Not not = new Not();
                edit = true;
            }
            if (verticalTouched < 2 && horizontalTouched > 15.0 && horizontalTouched < 20.0) {
                Tog tog = new Tog();
                edit = true;
            }
            if (verticalTouched < 2 && horizontalTouched > 20.0 && horizontalTouched < 25.0) {
                Out out = new Out();
                edit = true;
            }

        } else draw();
    }
    void draw() {
        gameView.setImageBitmap(blankBitmap);

        // Wipe the screen with a white color
        canvas.drawColor(Color.argb(255, 255, 255, 255));

        // Change the paint color to black
        paint.setColor(Color.argb(255, 0, 0, 0));

        // Draw the vertical lines of the grid
        for(int i = 0; i < gridWidth; i++){
            canvas.drawLine(blockSize * i, 0,
                    blockSize * i, numberVerticalPixels,
                    paint);
        }

        // Draw the horizontal lines of the grid
        for(int i = 0; i < gridHeight; i++){
            canvas.drawLine(0, blockSize * i,
                    numberHorizontalPixels, blockSize * i,
                    paint);
        }
        // Draw
        canvas.drawRect(horizontalTouched * blockSize,
                verticalTouched * blockSize,
                (horizontalTouched * blockSize) + blockSize,
                (verticalTouched * blockSize)+ blockSize,
                paint );


        // The represented buttons for the user
        //This is all the same string in the top of the screen
        paint.setTextSize(blockSize*2);
        paint.setColor(Color.argb(255, 0, 0, 255));
        canvas.drawText(
                "+And  " +"+Or  "+"+Not  "+ "+Switch  "+ "+Out  "+"DELETE",
                blockSize, blockSize * 2f,
                paint);
    }

    /*
        This part of the code will
        handle detecting that the player
        has tapped the screen
     */
    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        Log.d("Debugging", "In onTouchEvent");
        // Has the player removed their finger from the screen?
        if((motionEvent.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_UP) {

            // Process the player's shot by passing the
            // coordinates of the player's finger to touch
            touch(motionEvent.getX(), motionEvent.getY());
        }

        return true;
    }
        /*
        int horizontalGap = (int)horizontalTouched -
                subHorizontalPosition;
        int verticalGap = (int)verticalTouched -
                subVerticalPosition;

        // Use Pythagoras's theorem to get the
        // distance travelled in a straight line

        distanceFromSub = (int)Math.sqrt(
                ((horizontalGap * horizontalGap) +
                        (verticalGap * verticalGap)));

         */

}